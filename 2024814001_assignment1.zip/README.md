# CL-1-Assignment-1

Assumptions:
1. Contractions that are specific to words(watchin', o'er) are too complex to be handled by a simple cleaner like this.